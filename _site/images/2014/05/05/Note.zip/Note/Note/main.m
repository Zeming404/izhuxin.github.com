//
//  main.m
//  Note
//
//  Created by Jeason on 14-4-12.
//  Copyright (c) 2014年 Jeason. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "NoteAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([NoteAppDelegate class]));
    }
}
