//
//  NoteViewController.h
//  Note
//
//  Created by Jeason on 14-4-12.
//  Copyright (c) 2014年 Jeason. All rights reserved.
//

@import UIKit;
@class Note;

@interface NoteViewController : UIViewController

@property (nonatomic, strong) Note *note;

@end
