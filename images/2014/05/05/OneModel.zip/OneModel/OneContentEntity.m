//
//  OneContentEntity.m
//
//  Created by 新强 朱 on 14/11/29
//  Copyright (c) 2014 __MyCompanyName__. All rights reserved.
//

#import "OneContentEntity.h"


NSString *const kOneContentEntityStrContent = @"strContent";
NSString *const kOneContentEntitySRdNum = @"sRdNum";
NSString *const kOneContentEntityStrContentId = @"strContentId";
NSString *const kOneContentEntitySubTitle = @"subTitle";
NSString *const kOneContentEntityStrContDayDiffer = @"strContDayDiffer";
NSString *const kOneContentEntitySAuth = @"sAuth";
NSString *const kOneContentEntitySGW = @"sGW";
NSString *const kOneContentEntityStrLastUpdateDate = @"strLastUpdateDate";
NSString *const kOneContentEntityStrPraiseNumber = @"strPraiseNumber";
NSString *const kOneContentEntitySWebLk = @"sWebLk";
NSString *const kOneContentEntityWImgUrl = @"wImgUrl";
NSString *const kOneContentEntityStrContAuthorIntroduce = @"strContAuthorIntroduce";
NSString *const kOneContentEntityStrContTitle = @"strContTitle";
NSString *const kOneContentEntitySWbN = @"sWbN";
NSString *const kOneContentEntityStrContAuthor = @"strContAuthor";
NSString *const kOneContentEntityStrContMarketTime = @"strContMarketTime";


@interface OneContentEntity ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation OneContentEntity

@synthesize strContent = _strContent;
@synthesize sRdNum = _sRdNum;
@synthesize strContentId = _strContentId;
@synthesize subTitle = _subTitle;
@synthesize strContDayDiffer = _strContDayDiffer;
@synthesize sAuth = _sAuth;
@synthesize sGW = _sGW;
@synthesize strLastUpdateDate = _strLastUpdateDate;
@synthesize strPraiseNumber = _strPraiseNumber;
@synthesize sWebLk = _sWebLk;
@synthesize wImgUrl = _wImgUrl;
@synthesize strContAuthorIntroduce = _strContAuthorIntroduce;
@synthesize strContTitle = _strContTitle;
@synthesize sWbN = _sWbN;
@synthesize strContAuthor = _strContAuthor;
@synthesize strContMarketTime = _strContMarketTime;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict
{
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict
{
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if(self && [dict isKindOfClass:[NSDictionary class]]) {
            self.strContent = [self objectOrNilForKey:kOneContentEntityStrContent fromDictionary:dict];
            self.sRdNum = [self objectOrNilForKey:kOneContentEntitySRdNum fromDictionary:dict];
            self.strContentId = [self objectOrNilForKey:kOneContentEntityStrContentId fromDictionary:dict];
            self.subTitle = [self objectOrNilForKey:kOneContentEntitySubTitle fromDictionary:dict];
            self.strContDayDiffer = [self objectOrNilForKey:kOneContentEntityStrContDayDiffer fromDictionary:dict];
            self.sAuth = [self objectOrNilForKey:kOneContentEntitySAuth fromDictionary:dict];
            self.sGW = [self objectOrNilForKey:kOneContentEntitySGW fromDictionary:dict];
            self.strLastUpdateDate = [self objectOrNilForKey:kOneContentEntityStrLastUpdateDate fromDictionary:dict];
            self.strPraiseNumber = [self objectOrNilForKey:kOneContentEntityStrPraiseNumber fromDictionary:dict];
            self.sWebLk = [self objectOrNilForKey:kOneContentEntitySWebLk fromDictionary:dict];
            self.wImgUrl = [self objectOrNilForKey:kOneContentEntityWImgUrl fromDictionary:dict];
            self.strContAuthorIntroduce = [self objectOrNilForKey:kOneContentEntityStrContAuthorIntroduce fromDictionary:dict];
            self.strContTitle = [self objectOrNilForKey:kOneContentEntityStrContTitle fromDictionary:dict];
            self.sWbN = [self objectOrNilForKey:kOneContentEntitySWbN fromDictionary:dict];
            self.strContAuthor = [self objectOrNilForKey:kOneContentEntityStrContAuthor fromDictionary:dict];
            self.strContMarketTime = [self objectOrNilForKey:kOneContentEntityStrContMarketTime fromDictionary:dict];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation
{
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:self.strContent forKey:kOneContentEntityStrContent];
    [mutableDict setValue:self.sRdNum forKey:kOneContentEntitySRdNum];
    [mutableDict setValue:self.strContentId forKey:kOneContentEntityStrContentId];
    [mutableDict setValue:self.subTitle forKey:kOneContentEntitySubTitle];
    [mutableDict setValue:self.strContDayDiffer forKey:kOneContentEntityStrContDayDiffer];
    [mutableDict setValue:self.sAuth forKey:kOneContentEntitySAuth];
    [mutableDict setValue:self.sGW forKey:kOneContentEntitySGW];
    [mutableDict setValue:self.strLastUpdateDate forKey:kOneContentEntityStrLastUpdateDate];
    [mutableDict setValue:self.strPraiseNumber forKey:kOneContentEntityStrPraiseNumber];
    [mutableDict setValue:self.sWebLk forKey:kOneContentEntitySWebLk];
    [mutableDict setValue:self.wImgUrl forKey:kOneContentEntityWImgUrl];
    [mutableDict setValue:self.strContAuthorIntroduce forKey:kOneContentEntityStrContAuthorIntroduce];
    [mutableDict setValue:self.strContTitle forKey:kOneContentEntityStrContTitle];
    [mutableDict setValue:self.sWbN forKey:kOneContentEntitySWbN];
    [mutableDict setValue:self.strContAuthor forKey:kOneContentEntityStrContAuthor];
    [mutableDict setValue:self.strContMarketTime forKey:kOneContentEntityStrContMarketTime];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description 
{
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict
{
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];

    self.strContent = [aDecoder decodeObjectForKey:kOneContentEntityStrContent];
    self.sRdNum = [aDecoder decodeObjectForKey:kOneContentEntitySRdNum];
    self.strContentId = [aDecoder decodeObjectForKey:kOneContentEntityStrContentId];
    self.subTitle = [aDecoder decodeObjectForKey:kOneContentEntitySubTitle];
    self.strContDayDiffer = [aDecoder decodeObjectForKey:kOneContentEntityStrContDayDiffer];
    self.sAuth = [aDecoder decodeObjectForKey:kOneContentEntitySAuth];
    self.sGW = [aDecoder decodeObjectForKey:kOneContentEntitySGW];
    self.strLastUpdateDate = [aDecoder decodeObjectForKey:kOneContentEntityStrLastUpdateDate];
    self.strPraiseNumber = [aDecoder decodeObjectForKey:kOneContentEntityStrPraiseNumber];
    self.sWebLk = [aDecoder decodeObjectForKey:kOneContentEntitySWebLk];
    self.wImgUrl = [aDecoder decodeObjectForKey:kOneContentEntityWImgUrl];
    self.strContAuthorIntroduce = [aDecoder decodeObjectForKey:kOneContentEntityStrContAuthorIntroduce];
    self.strContTitle = [aDecoder decodeObjectForKey:kOneContentEntityStrContTitle];
    self.sWbN = [aDecoder decodeObjectForKey:kOneContentEntitySWbN];
    self.strContAuthor = [aDecoder decodeObjectForKey:kOneContentEntityStrContAuthor];
    self.strContMarketTime = [aDecoder decodeObjectForKey:kOneContentEntityStrContMarketTime];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeObject:_strContent forKey:kOneContentEntityStrContent];
    [aCoder encodeObject:_sRdNum forKey:kOneContentEntitySRdNum];
    [aCoder encodeObject:_strContentId forKey:kOneContentEntityStrContentId];
    [aCoder encodeObject:_subTitle forKey:kOneContentEntitySubTitle];
    [aCoder encodeObject:_strContDayDiffer forKey:kOneContentEntityStrContDayDiffer];
    [aCoder encodeObject:_sAuth forKey:kOneContentEntitySAuth];
    [aCoder encodeObject:_sGW forKey:kOneContentEntitySGW];
    [aCoder encodeObject:_strLastUpdateDate forKey:kOneContentEntityStrLastUpdateDate];
    [aCoder encodeObject:_strPraiseNumber forKey:kOneContentEntityStrPraiseNumber];
    [aCoder encodeObject:_sWebLk forKey:kOneContentEntitySWebLk];
    [aCoder encodeObject:_wImgUrl forKey:kOneContentEntityWImgUrl];
    [aCoder encodeObject:_strContAuthorIntroduce forKey:kOneContentEntityStrContAuthorIntroduce];
    [aCoder encodeObject:_strContTitle forKey:kOneContentEntityStrContTitle];
    [aCoder encodeObject:_sWbN forKey:kOneContentEntitySWbN];
    [aCoder encodeObject:_strContAuthor forKey:kOneContentEntityStrContAuthor];
    [aCoder encodeObject:_strContMarketTime forKey:kOneContentEntityStrContMarketTime];
}

- (id)copyWithZone:(NSZone *)zone
{
    OneContentEntity *copy = [[OneContentEntity alloc] init];
    
    if (copy) {

        copy.strContent = [self.strContent copyWithZone:zone];
        copy.sRdNum = [self.sRdNum copyWithZone:zone];
        copy.strContentId = [self.strContentId copyWithZone:zone];
        copy.subTitle = [self.subTitle copyWithZone:zone];
        copy.strContDayDiffer = [self.strContDayDiffer copyWithZone:zone];
        copy.sAuth = [self.sAuth copyWithZone:zone];
        copy.sGW = [self.sGW copyWithZone:zone];
        copy.strLastUpdateDate = [self.strLastUpdateDate copyWithZone:zone];
        copy.strPraiseNumber = [self.strPraiseNumber copyWithZone:zone];
        copy.sWebLk = [self.sWebLk copyWithZone:zone];
        copy.wImgUrl = [self.wImgUrl copyWithZone:zone];
        copy.strContAuthorIntroduce = [self.strContAuthorIntroduce copyWithZone:zone];
        copy.strContTitle = [self.strContTitle copyWithZone:zone];
        copy.sWbN = [self.sWbN copyWithZone:zone];
        copy.strContAuthor = [self.strContAuthor copyWithZone:zone];
        copy.strContMarketTime = [self.strContMarketTime copyWithZone:zone];
    }
    
    return copy;
}


@end
