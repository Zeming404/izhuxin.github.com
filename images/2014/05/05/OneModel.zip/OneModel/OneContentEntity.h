//
//  OneContentEntity.h
//
//  Created by 新强 朱 on 14/11/29
//  Copyright (c) 2014 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface OneContentEntity : NSObject <NSCoding, NSCopying>

@property (nonatomic, strong) NSString *strContent;
@property (nonatomic, strong) NSString *sRdNum;
@property (nonatomic, strong) NSString *strContentId;
@property (nonatomic, strong) NSString *subTitle;
@property (nonatomic, strong) NSString *strContDayDiffer;
@property (nonatomic, strong) NSString *sAuth;
@property (nonatomic, strong) NSString *sGW;
@property (nonatomic, strong) NSString *strLastUpdateDate;
@property (nonatomic, strong) NSString *strPraiseNumber;
@property (nonatomic, strong) NSString *sWebLk;
@property (nonatomic, strong) NSString *wImgUrl;
@property (nonatomic, strong) NSString *strContAuthorIntroduce;
@property (nonatomic, strong) NSString *strContTitle;
@property (nonatomic, strong) NSString *sWbN;
@property (nonatomic, strong) NSString *strContAuthor;
@property (nonatomic, strong) NSString *strContMarketTime;

+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict;
- (instancetype)initWithDictionary:(NSDictionary *)dict;
- (NSDictionary *)dictionaryRepresentation;

@end
