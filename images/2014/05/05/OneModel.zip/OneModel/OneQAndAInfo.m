//
//  OneQAndAInfo.m
//
//  Created by 新强 朱 on 14/11/29
//  Copyright (c) 2014 __MyCompanyName__. All rights reserved.
//

#import "OneQAndAInfo.h"
#import "OneQuestionAdEntity.h"


NSString *const kOneQAndAInfoResult = @"result";
NSString *const kOneQAndAInfoQuestionAdEntity = @"questionAdEntity";


@interface OneQAndAInfo ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation OneQAndAInfo

@synthesize result = _result;
@synthesize questionAdEntity = _questionAdEntity;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict
{
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict
{
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if(self && [dict isKindOfClass:[NSDictionary class]]) {
            self.result = [self objectOrNilForKey:kOneQAndAInfoResult fromDictionary:dict];
            self.questionAdEntity = [OneQuestionAdEntity modelObjectWithDictionary:[dict objectForKey:kOneQAndAInfoQuestionAdEntity]];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation
{
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:self.result forKey:kOneQAndAInfoResult];
    [mutableDict setValue:[self.questionAdEntity dictionaryRepresentation] forKey:kOneQAndAInfoQuestionAdEntity];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description 
{
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict
{
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];

    self.result = [aDecoder decodeObjectForKey:kOneQAndAInfoResult];
    self.questionAdEntity = [aDecoder decodeObjectForKey:kOneQAndAInfoQuestionAdEntity];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeObject:_result forKey:kOneQAndAInfoResult];
    [aCoder encodeObject:_questionAdEntity forKey:kOneQAndAInfoQuestionAdEntity];
}

- (id)copyWithZone:(NSZone *)zone
{
    OneQAndAInfo *copy = [[OneQAndAInfo alloc] init];
    
    if (copy) {

        copy.result = [self.result copyWithZone:zone];
        copy.questionAdEntity = [self.questionAdEntity copyWithZone:zone];
    }
    
    return copy;
}


@end
