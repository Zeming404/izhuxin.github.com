//
//  OneEntTg.m
//
//  Created by 新强 朱 on 14/11/29
//  Copyright (c) 2014 __MyCompanyName__. All rights reserved.
//

#import "OneEntTg.h"


NSString *const kOneEntTgStrTt = @"strTt";
NSString *const kOneEntTgStrId = @"strId";
NSString *const kOneEntTgStrTm = @"strTm";
NSString *const kOneEntTgStrPn = @"strPn";
NSString *const kOneEntTgStrLastUpdateDate = @"strLastUpdateDate";
NSString *const kOneEntTgStrBu = @"strBu";
NSString *const kOneEntTgStrWu = @"strWu";
NSString *const kOneEntTgStrTc = @"strTc";


@interface OneEntTg ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation OneEntTg

@synthesize strTt = _strTt;
@synthesize strId = _strId;
@synthesize strTm = _strTm;
@synthesize strPn = _strPn;
@synthesize strLastUpdateDate = _strLastUpdateDate;
@synthesize strBu = _strBu;
@synthesize strWu = _strWu;
@synthesize strTc = _strTc;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict
{
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict
{
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if(self && [dict isKindOfClass:[NSDictionary class]]) {
            self.strTt = [self objectOrNilForKey:kOneEntTgStrTt fromDictionary:dict];
            self.strId = [self objectOrNilForKey:kOneEntTgStrId fromDictionary:dict];
            self.strTm = [self objectOrNilForKey:kOneEntTgStrTm fromDictionary:dict];
            self.strPn = [self objectOrNilForKey:kOneEntTgStrPn fromDictionary:dict];
            self.strLastUpdateDate = [self objectOrNilForKey:kOneEntTgStrLastUpdateDate fromDictionary:dict];
            self.strBu = [self objectOrNilForKey:kOneEntTgStrBu fromDictionary:dict];
            self.strWu = [self objectOrNilForKey:kOneEntTgStrWu fromDictionary:dict];
            self.strTc = [self objectOrNilForKey:kOneEntTgStrTc fromDictionary:dict];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation
{
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:self.strTt forKey:kOneEntTgStrTt];
    [mutableDict setValue:self.strId forKey:kOneEntTgStrId];
    [mutableDict setValue:self.strTm forKey:kOneEntTgStrTm];
    [mutableDict setValue:self.strPn forKey:kOneEntTgStrPn];
    [mutableDict setValue:self.strLastUpdateDate forKey:kOneEntTgStrLastUpdateDate];
    [mutableDict setValue:self.strBu forKey:kOneEntTgStrBu];
    [mutableDict setValue:self.strWu forKey:kOneEntTgStrWu];
    [mutableDict setValue:self.strTc forKey:kOneEntTgStrTc];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description 
{
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict
{
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];

    self.strTt = [aDecoder decodeObjectForKey:kOneEntTgStrTt];
    self.strId = [aDecoder decodeObjectForKey:kOneEntTgStrId];
    self.strTm = [aDecoder decodeObjectForKey:kOneEntTgStrTm];
    self.strPn = [aDecoder decodeObjectForKey:kOneEntTgStrPn];
    self.strLastUpdateDate = [aDecoder decodeObjectForKey:kOneEntTgStrLastUpdateDate];
    self.strBu = [aDecoder decodeObjectForKey:kOneEntTgStrBu];
    self.strWu = [aDecoder decodeObjectForKey:kOneEntTgStrWu];
    self.strTc = [aDecoder decodeObjectForKey:kOneEntTgStrTc];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeObject:_strTt forKey:kOneEntTgStrTt];
    [aCoder encodeObject:_strId forKey:kOneEntTgStrId];
    [aCoder encodeObject:_strTm forKey:kOneEntTgStrTm];
    [aCoder encodeObject:_strPn forKey:kOneEntTgStrPn];
    [aCoder encodeObject:_strLastUpdateDate forKey:kOneEntTgStrLastUpdateDate];
    [aCoder encodeObject:_strBu forKey:kOneEntTgStrBu];
    [aCoder encodeObject:_strWu forKey:kOneEntTgStrWu];
    [aCoder encodeObject:_strTc forKey:kOneEntTgStrTc];
}

- (id)copyWithZone:(NSZone *)zone
{
    OneEntTg *copy = [[OneEntTg alloc] init];
    
    if (copy) {

        copy.strTt = [self.strTt copyWithZone:zone];
        copy.strId = [self.strId copyWithZone:zone];
        copy.strTm = [self.strTm copyWithZone:zone];
        copy.strPn = [self.strPn copyWithZone:zone];
        copy.strLastUpdateDate = [self.strLastUpdateDate copyWithZone:zone];
        copy.strBu = [self.strBu copyWithZone:zone];
        copy.strWu = [self.strWu copyWithZone:zone];
        copy.strTc = [self.strTc copyWithZone:zone];
    }
    
    return copy;
}


@end
