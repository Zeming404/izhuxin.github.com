//
//  OneItemInfo.m
//
//  Created by 新强 朱 on 14/11/29
//  Copyright (c) 2014 __MyCompanyName__. All rights reserved.
//

#import "OneItemInfo.h"
#import "OneEntTg.h"


NSString *const kOneItemInfoRs = @"rs";
NSString *const kOneItemInfoEntTg = @"entTg";


@interface OneItemInfo ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation OneItemInfo

@synthesize rs = _rs;
@synthesize entTg = _entTg;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict
{
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict
{
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if(self && [dict isKindOfClass:[NSDictionary class]]) {
            self.rs = [self objectOrNilForKey:kOneItemInfoRs fromDictionary:dict];
            self.entTg = [OneEntTg modelObjectWithDictionary:[dict objectForKey:kOneItemInfoEntTg]];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation
{
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:self.rs forKey:kOneItemInfoRs];
    [mutableDict setValue:[self.entTg dictionaryRepresentation] forKey:kOneItemInfoEntTg];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description 
{
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict
{
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];

    self.rs = [aDecoder decodeObjectForKey:kOneItemInfoRs];
    self.entTg = [aDecoder decodeObjectForKey:kOneItemInfoEntTg];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeObject:_rs forKey:kOneItemInfoRs];
    [aCoder encodeObject:_entTg forKey:kOneItemInfoEntTg];
}

- (id)copyWithZone:(NSZone *)zone
{
    OneItemInfo *copy = [[OneItemInfo alloc] init];
    
    if (copy) {

        copy.rs = [self.rs copyWithZone:zone];
        copy.entTg = [self.entTg copyWithZone:zone];
    }
    
    return copy;
}


@end
