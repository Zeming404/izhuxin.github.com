//
//  OneHeadPageModel.m
//
//  Created by 新强 朱 on 14/11/29
//  Copyright (c) 2014 __MyCompanyName__. All rights reserved.
//

#import "OneHeadPageModel.h"
#import "OneHpEntity.h"


NSString *const kOneHeadPageModelResult = @"result";
NSString *const kOneHeadPageModelHpEntity = @"hpEntity";


@interface OneHeadPageModel ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation OneHeadPageModel

@synthesize result = _result;
@synthesize hpEntity = _hpEntity;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict
{
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict
{
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if(self && [dict isKindOfClass:[NSDictionary class]]) {
            self.result = [self objectOrNilForKey:kOneHeadPageModelResult fromDictionary:dict];
            self.hpEntity = [OneHpEntity modelObjectWithDictionary:[dict objectForKey:kOneHeadPageModelHpEntity]];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation
{
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:self.result forKey:kOneHeadPageModelResult];
    [mutableDict setValue:[self.hpEntity dictionaryRepresentation] forKey:kOneHeadPageModelHpEntity];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description 
{
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict
{
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];

    self.result = [aDecoder decodeObjectForKey:kOneHeadPageModelResult];
    self.hpEntity = [aDecoder decodeObjectForKey:kOneHeadPageModelHpEntity];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeObject:_result forKey:kOneHeadPageModelResult];
    [aCoder encodeObject:_hpEntity forKey:kOneHeadPageModelHpEntity];
}

- (id)copyWithZone:(NSZone *)zone
{
    OneHeadPageModel *copy = [[OneHeadPageModel alloc] init];
    
    if (copy) {

        copy.result = [self.result copyWithZone:zone];
        copy.hpEntity = [self.hpEntity copyWithZone:zone];
    }
    
    return copy;
}


@end
