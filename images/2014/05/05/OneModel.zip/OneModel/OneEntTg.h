//
//  OneEntTg.h
//
//  Created by 新强 朱 on 14/11/29
//  Copyright (c) 2014 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface OneEntTg : NSObject <NSCoding, NSCopying>

@property (nonatomic, strong) NSString *strTt;
@property (nonatomic, strong) NSString *strId;
@property (nonatomic, strong) NSString *strTm;
@property (nonatomic, strong) NSString *strPn;
@property (nonatomic, strong) NSString *strLastUpdateDate;
@property (nonatomic, strong) NSString *strBu;
@property (nonatomic, strong) NSString *strWu;
@property (nonatomic, strong) NSString *strTc;

+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict;
- (instancetype)initWithDictionary:(NSDictionary *)dict;
- (NSDictionary *)dictionaryRepresentation;

@end
