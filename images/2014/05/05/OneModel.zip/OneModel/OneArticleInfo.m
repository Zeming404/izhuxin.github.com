//
//  OneArticleInfo.m
//
//  Created by 新强 朱 on 14/11/29
//  Copyright (c) 2014 __MyCompanyName__. All rights reserved.
//

#import "OneArticleInfo.h"
#import "OneContentEntity.h"


NSString *const kOneArticleInfoContentEntity = @"contentEntity";
NSString *const kOneArticleInfoResult = @"result";


@interface OneArticleInfo ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation OneArticleInfo

@synthesize contentEntity = _contentEntity;
@synthesize result = _result;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict
{
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict
{
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if(self && [dict isKindOfClass:[NSDictionary class]]) {
            self.contentEntity = [OneContentEntity modelObjectWithDictionary:[dict objectForKey:kOneArticleInfoContentEntity]];
            self.result = [self objectOrNilForKey:kOneArticleInfoResult fromDictionary:dict];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation
{
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:[self.contentEntity dictionaryRepresentation] forKey:kOneArticleInfoContentEntity];
    [mutableDict setValue:self.result forKey:kOneArticleInfoResult];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description 
{
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict
{
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];

    self.contentEntity = [aDecoder decodeObjectForKey:kOneArticleInfoContentEntity];
    self.result = [aDecoder decodeObjectForKey:kOneArticleInfoResult];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeObject:_contentEntity forKey:kOneArticleInfoContentEntity];
    [aCoder encodeObject:_result forKey:kOneArticleInfoResult];
}

- (id)copyWithZone:(NSZone *)zone
{
    OneArticleInfo *copy = [[OneArticleInfo alloc] init];
    
    if (copy) {

        copy.contentEntity = [self.contentEntity copyWithZone:zone];
        copy.result = [self.result copyWithZone:zone];
    }
    
    return copy;
}


@end
