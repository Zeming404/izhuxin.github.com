//
//  OneEntQNCmt.h
//
//  Created by 新强 朱 on 14/11/29
//  Copyright (c) 2014 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface OneEntQNCmt : NSObject <NSCoding, NSCopying>

@property (nonatomic, strong) NSString *pNum;
@property (nonatomic, strong) NSString *strCnt;
@property (nonatomic, strong) NSString *strId;
@property (nonatomic, strong) NSString *upFg;
@property (nonatomic, strong) NSString *strD;

+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict;
- (instancetype)initWithDictionary:(NSDictionary *)dict;
- (NSDictionary *)dictionaryRepresentation;

@end
