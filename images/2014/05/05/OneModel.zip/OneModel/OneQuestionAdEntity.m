//
//  OneQuestionAdEntity.m
//
//  Created by 新强 朱 on 14/11/29
//  Copyright (c) 2014 __MyCompanyName__. All rights reserved.
//

#import "OneQuestionAdEntity.h"
#import "OneEntQNCmt.h"


NSString *const kOneQuestionAdEntitySWebLk = @"sWebLk";
NSString *const kOneQuestionAdEntityStrQuestionId = @"strQuestionId";
NSString *const kOneQuestionAdEntityStrAnswerTitle = @"strAnswerTitle";
NSString *const kOneQuestionAdEntityStrQuestionContent = @"strQuestionContent";
NSString *const kOneQuestionAdEntityStrQuestionMarketTime = @"strQuestionMarketTime";
NSString *const kOneQuestionAdEntityStrLastUpdateDate = @"strLastUpdateDate";
NSString *const kOneQuestionAdEntityStrPraiseNumber = @"strPraiseNumber";
NSString *const kOneQuestionAdEntityStrDayDiffer = @"strDayDiffer";
NSString *const kOneQuestionAdEntityStrQuestionTitle = @"strQuestionTitle";
NSString *const kOneQuestionAdEntityStrAnswerContent = @"strAnswerContent";
NSString *const kOneQuestionAdEntityEntQNCmt = @"entQNCmt";


@interface OneQuestionAdEntity ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation OneQuestionAdEntity

@synthesize sWebLk = _sWebLk;
@synthesize strQuestionId = _strQuestionId;
@synthesize strAnswerTitle = _strAnswerTitle;
@synthesize strQuestionContent = _strQuestionContent;
@synthesize strQuestionMarketTime = _strQuestionMarketTime;
@synthesize strLastUpdateDate = _strLastUpdateDate;
@synthesize strPraiseNumber = _strPraiseNumber;
@synthesize strDayDiffer = _strDayDiffer;
@synthesize strQuestionTitle = _strQuestionTitle;
@synthesize strAnswerContent = _strAnswerContent;
@synthesize entQNCmt = _entQNCmt;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict
{
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict
{
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if(self && [dict isKindOfClass:[NSDictionary class]]) {
            self.sWebLk = [self objectOrNilForKey:kOneQuestionAdEntitySWebLk fromDictionary:dict];
            self.strQuestionId = [self objectOrNilForKey:kOneQuestionAdEntityStrQuestionId fromDictionary:dict];
            self.strAnswerTitle = [self objectOrNilForKey:kOneQuestionAdEntityStrAnswerTitle fromDictionary:dict];
            self.strQuestionContent = [self objectOrNilForKey:kOneQuestionAdEntityStrQuestionContent fromDictionary:dict];
            self.strQuestionMarketTime = [self objectOrNilForKey:kOneQuestionAdEntityStrQuestionMarketTime fromDictionary:dict];
            self.strLastUpdateDate = [self objectOrNilForKey:kOneQuestionAdEntityStrLastUpdateDate fromDictionary:dict];
            self.strPraiseNumber = [self objectOrNilForKey:kOneQuestionAdEntityStrPraiseNumber fromDictionary:dict];
            self.strDayDiffer = [self objectOrNilForKey:kOneQuestionAdEntityStrDayDiffer fromDictionary:dict];
            self.strQuestionTitle = [self objectOrNilForKey:kOneQuestionAdEntityStrQuestionTitle fromDictionary:dict];
            self.strAnswerContent = [self objectOrNilForKey:kOneQuestionAdEntityStrAnswerContent fromDictionary:dict];
            self.entQNCmt = [OneEntQNCmt modelObjectWithDictionary:[dict objectForKey:kOneQuestionAdEntityEntQNCmt]];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation
{
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:self.sWebLk forKey:kOneQuestionAdEntitySWebLk];
    [mutableDict setValue:self.strQuestionId forKey:kOneQuestionAdEntityStrQuestionId];
    [mutableDict setValue:self.strAnswerTitle forKey:kOneQuestionAdEntityStrAnswerTitle];
    [mutableDict setValue:self.strQuestionContent forKey:kOneQuestionAdEntityStrQuestionContent];
    [mutableDict setValue:self.strQuestionMarketTime forKey:kOneQuestionAdEntityStrQuestionMarketTime];
    [mutableDict setValue:self.strLastUpdateDate forKey:kOneQuestionAdEntityStrLastUpdateDate];
    [mutableDict setValue:self.strPraiseNumber forKey:kOneQuestionAdEntityStrPraiseNumber];
    [mutableDict setValue:self.strDayDiffer forKey:kOneQuestionAdEntityStrDayDiffer];
    [mutableDict setValue:self.strQuestionTitle forKey:kOneQuestionAdEntityStrQuestionTitle];
    [mutableDict setValue:self.strAnswerContent forKey:kOneQuestionAdEntityStrAnswerContent];
    [mutableDict setValue:[self.entQNCmt dictionaryRepresentation] forKey:kOneQuestionAdEntityEntQNCmt];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description 
{
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict
{
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];

    self.sWebLk = [aDecoder decodeObjectForKey:kOneQuestionAdEntitySWebLk];
    self.strQuestionId = [aDecoder decodeObjectForKey:kOneQuestionAdEntityStrQuestionId];
    self.strAnswerTitle = [aDecoder decodeObjectForKey:kOneQuestionAdEntityStrAnswerTitle];
    self.strQuestionContent = [aDecoder decodeObjectForKey:kOneQuestionAdEntityStrQuestionContent];
    self.strQuestionMarketTime = [aDecoder decodeObjectForKey:kOneQuestionAdEntityStrQuestionMarketTime];
    self.strLastUpdateDate = [aDecoder decodeObjectForKey:kOneQuestionAdEntityStrLastUpdateDate];
    self.strPraiseNumber = [aDecoder decodeObjectForKey:kOneQuestionAdEntityStrPraiseNumber];
    self.strDayDiffer = [aDecoder decodeObjectForKey:kOneQuestionAdEntityStrDayDiffer];
    self.strQuestionTitle = [aDecoder decodeObjectForKey:kOneQuestionAdEntityStrQuestionTitle];
    self.strAnswerContent = [aDecoder decodeObjectForKey:kOneQuestionAdEntityStrAnswerContent];
    self.entQNCmt = [aDecoder decodeObjectForKey:kOneQuestionAdEntityEntQNCmt];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeObject:_sWebLk forKey:kOneQuestionAdEntitySWebLk];
    [aCoder encodeObject:_strQuestionId forKey:kOneQuestionAdEntityStrQuestionId];
    [aCoder encodeObject:_strAnswerTitle forKey:kOneQuestionAdEntityStrAnswerTitle];
    [aCoder encodeObject:_strQuestionContent forKey:kOneQuestionAdEntityStrQuestionContent];
    [aCoder encodeObject:_strQuestionMarketTime forKey:kOneQuestionAdEntityStrQuestionMarketTime];
    [aCoder encodeObject:_strLastUpdateDate forKey:kOneQuestionAdEntityStrLastUpdateDate];
    [aCoder encodeObject:_strPraiseNumber forKey:kOneQuestionAdEntityStrPraiseNumber];
    [aCoder encodeObject:_strDayDiffer forKey:kOneQuestionAdEntityStrDayDiffer];
    [aCoder encodeObject:_strQuestionTitle forKey:kOneQuestionAdEntityStrQuestionTitle];
    [aCoder encodeObject:_strAnswerContent forKey:kOneQuestionAdEntityStrAnswerContent];
    [aCoder encodeObject:_entQNCmt forKey:kOneQuestionAdEntityEntQNCmt];
}

- (id)copyWithZone:(NSZone *)zone
{
    OneQuestionAdEntity *copy = [[OneQuestionAdEntity alloc] init];
    
    if (copy) {

        copy.sWebLk = [self.sWebLk copyWithZone:zone];
        copy.strQuestionId = [self.strQuestionId copyWithZone:zone];
        copy.strAnswerTitle = [self.strAnswerTitle copyWithZone:zone];
        copy.strQuestionContent = [self.strQuestionContent copyWithZone:zone];
        copy.strQuestionMarketTime = [self.strQuestionMarketTime copyWithZone:zone];
        copy.strLastUpdateDate = [self.strLastUpdateDate copyWithZone:zone];
        copy.strPraiseNumber = [self.strPraiseNumber copyWithZone:zone];
        copy.strDayDiffer = [self.strDayDiffer copyWithZone:zone];
        copy.strQuestionTitle = [self.strQuestionTitle copyWithZone:zone];
        copy.strAnswerContent = [self.strAnswerContent copyWithZone:zone];
        copy.entQNCmt = [self.entQNCmt copyWithZone:zone];
    }
    
    return copy;
}


@end
