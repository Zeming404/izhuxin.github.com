//
//  OneItemInfo.h
//
//  Created by 新强 朱 on 14/11/29
//  Copyright (c) 2014 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class OneEntTg;

@interface OneItemInfo : NSObject <NSCoding, NSCopying>

@property (nonatomic, strong) NSString *rs;
@property (nonatomic, strong) OneEntTg *entTg;

+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict;
- (instancetype)initWithDictionary:(NSDictionary *)dict;
- (NSDictionary *)dictionaryRepresentation;

@end
