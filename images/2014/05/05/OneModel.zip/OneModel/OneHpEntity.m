//
//  OneHpEntity.m
//
//  Created by 新强 朱 on 14/11/29
//  Copyright (c) 2014 __MyCompanyName__. All rights reserved.
//

#import "OneHpEntity.h"


NSString *const kOneHpEntityStrContent = @"strContent";
NSString *const kOneHpEntityStrThumbnailUrl = @"strThumbnailUrl";
NSString *const kOneHpEntityStrLastUpdateDate = @"strLastUpdateDate";
NSString *const kOneHpEntityStrOriginalImgUrl = @"strOriginalImgUrl";
NSString *const kOneHpEntityStrHpId = @"strHpId";
NSString *const kOneHpEntitySWebLk = @"sWebLk";
NSString *const kOneHpEntityWImgUrl = @"wImgUrl";
NSString *const kOneHpEntityStrPn = @"strPn";
NSString *const kOneHpEntityStrDayDiffer = @"strDayDiffer";
NSString *const kOneHpEntityStrAuthor = @"strAuthor";
NSString *const kOneHpEntityStrHpTitle = @"strHpTitle";
NSString *const kOneHpEntityStrMarketTime = @"strMarketTime";


@interface OneHpEntity ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation OneHpEntity

@synthesize strContent = _strContent;
@synthesize strThumbnailUrl = _strThumbnailUrl;
@synthesize strLastUpdateDate = _strLastUpdateDate;
@synthesize strOriginalImgUrl = _strOriginalImgUrl;
@synthesize strHpId = _strHpId;
@synthesize sWebLk = _sWebLk;
@synthesize wImgUrl = _wImgUrl;
@synthesize strPn = _strPn;
@synthesize strDayDiffer = _strDayDiffer;
@synthesize strAuthor = _strAuthor;
@synthesize strHpTitle = _strHpTitle;
@synthesize strMarketTime = _strMarketTime;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict
{
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict
{
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if(self && [dict isKindOfClass:[NSDictionary class]]) {
            self.strContent = [self objectOrNilForKey:kOneHpEntityStrContent fromDictionary:dict];
            self.strThumbnailUrl = [self objectOrNilForKey:kOneHpEntityStrThumbnailUrl fromDictionary:dict];
            self.strLastUpdateDate = [self objectOrNilForKey:kOneHpEntityStrLastUpdateDate fromDictionary:dict];
            self.strOriginalImgUrl = [self objectOrNilForKey:kOneHpEntityStrOriginalImgUrl fromDictionary:dict];
            self.strHpId = [self objectOrNilForKey:kOneHpEntityStrHpId fromDictionary:dict];
            self.sWebLk = [self objectOrNilForKey:kOneHpEntitySWebLk fromDictionary:dict];
            self.wImgUrl = [self objectOrNilForKey:kOneHpEntityWImgUrl fromDictionary:dict];
            self.strPn = [self objectOrNilForKey:kOneHpEntityStrPn fromDictionary:dict];
            self.strDayDiffer = [self objectOrNilForKey:kOneHpEntityStrDayDiffer fromDictionary:dict];
            self.strAuthor = [self objectOrNilForKey:kOneHpEntityStrAuthor fromDictionary:dict];
            self.strHpTitle = [self objectOrNilForKey:kOneHpEntityStrHpTitle fromDictionary:dict];
            self.strMarketTime = [self objectOrNilForKey:kOneHpEntityStrMarketTime fromDictionary:dict];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation
{
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:self.strContent forKey:kOneHpEntityStrContent];
    [mutableDict setValue:self.strThumbnailUrl forKey:kOneHpEntityStrThumbnailUrl];
    [mutableDict setValue:self.strLastUpdateDate forKey:kOneHpEntityStrLastUpdateDate];
    [mutableDict setValue:self.strOriginalImgUrl forKey:kOneHpEntityStrOriginalImgUrl];
    [mutableDict setValue:self.strHpId forKey:kOneHpEntityStrHpId];
    [mutableDict setValue:self.sWebLk forKey:kOneHpEntitySWebLk];
    [mutableDict setValue:self.wImgUrl forKey:kOneHpEntityWImgUrl];
    [mutableDict setValue:self.strPn forKey:kOneHpEntityStrPn];
    [mutableDict setValue:self.strDayDiffer forKey:kOneHpEntityStrDayDiffer];
    [mutableDict setValue:self.strAuthor forKey:kOneHpEntityStrAuthor];
    [mutableDict setValue:self.strHpTitle forKey:kOneHpEntityStrHpTitle];
    [mutableDict setValue:self.strMarketTime forKey:kOneHpEntityStrMarketTime];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description 
{
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict
{
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];

    self.strContent = [aDecoder decodeObjectForKey:kOneHpEntityStrContent];
    self.strThumbnailUrl = [aDecoder decodeObjectForKey:kOneHpEntityStrThumbnailUrl];
    self.strLastUpdateDate = [aDecoder decodeObjectForKey:kOneHpEntityStrLastUpdateDate];
    self.strOriginalImgUrl = [aDecoder decodeObjectForKey:kOneHpEntityStrOriginalImgUrl];
    self.strHpId = [aDecoder decodeObjectForKey:kOneHpEntityStrHpId];
    self.sWebLk = [aDecoder decodeObjectForKey:kOneHpEntitySWebLk];
    self.wImgUrl = [aDecoder decodeObjectForKey:kOneHpEntityWImgUrl];
    self.strPn = [aDecoder decodeObjectForKey:kOneHpEntityStrPn];
    self.strDayDiffer = [aDecoder decodeObjectForKey:kOneHpEntityStrDayDiffer];
    self.strAuthor = [aDecoder decodeObjectForKey:kOneHpEntityStrAuthor];
    self.strHpTitle = [aDecoder decodeObjectForKey:kOneHpEntityStrHpTitle];
    self.strMarketTime = [aDecoder decodeObjectForKey:kOneHpEntityStrMarketTime];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeObject:_strContent forKey:kOneHpEntityStrContent];
    [aCoder encodeObject:_strThumbnailUrl forKey:kOneHpEntityStrThumbnailUrl];
    [aCoder encodeObject:_strLastUpdateDate forKey:kOneHpEntityStrLastUpdateDate];
    [aCoder encodeObject:_strOriginalImgUrl forKey:kOneHpEntityStrOriginalImgUrl];
    [aCoder encodeObject:_strHpId forKey:kOneHpEntityStrHpId];
    [aCoder encodeObject:_sWebLk forKey:kOneHpEntitySWebLk];
    [aCoder encodeObject:_wImgUrl forKey:kOneHpEntityWImgUrl];
    [aCoder encodeObject:_strPn forKey:kOneHpEntityStrPn];
    [aCoder encodeObject:_strDayDiffer forKey:kOneHpEntityStrDayDiffer];
    [aCoder encodeObject:_strAuthor forKey:kOneHpEntityStrAuthor];
    [aCoder encodeObject:_strHpTitle forKey:kOneHpEntityStrHpTitle];
    [aCoder encodeObject:_strMarketTime forKey:kOneHpEntityStrMarketTime];
}

- (id)copyWithZone:(NSZone *)zone
{
    OneHpEntity *copy = [[OneHpEntity alloc] init];
    
    if (copy) {

        copy.strContent = [self.strContent copyWithZone:zone];
        copy.strThumbnailUrl = [self.strThumbnailUrl copyWithZone:zone];
        copy.strLastUpdateDate = [self.strLastUpdateDate copyWithZone:zone];
        copy.strOriginalImgUrl = [self.strOriginalImgUrl copyWithZone:zone];
        copy.strHpId = [self.strHpId copyWithZone:zone];
        copy.sWebLk = [self.sWebLk copyWithZone:zone];
        copy.wImgUrl = [self.wImgUrl copyWithZone:zone];
        copy.strPn = [self.strPn copyWithZone:zone];
        copy.strDayDiffer = [self.strDayDiffer copyWithZone:zone];
        copy.strAuthor = [self.strAuthor copyWithZone:zone];
        copy.strHpTitle = [self.strHpTitle copyWithZone:zone];
        copy.strMarketTime = [self.strMarketTime copyWithZone:zone];
    }
    
    return copy;
}


@end
