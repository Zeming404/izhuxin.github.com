//
//  OneEntQNCmt.m
//
//  Created by 新强 朱 on 14/11/29
//  Copyright (c) 2014 __MyCompanyName__. All rights reserved.
//

#import "OneEntQNCmt.h"


NSString *const kOneEntQNCmtPNum = @"pNum";
NSString *const kOneEntQNCmtStrCnt = @"strCnt";
NSString *const kOneEntQNCmtStrId = @"strId";
NSString *const kOneEntQNCmtUpFg = @"upFg";
NSString *const kOneEntQNCmtStrD = @"strD";


@interface OneEntQNCmt ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation OneEntQNCmt

@synthesize pNum = _pNum;
@synthesize strCnt = _strCnt;
@synthesize strId = _strId;
@synthesize upFg = _upFg;
@synthesize strD = _strD;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict
{
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict
{
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if(self && [dict isKindOfClass:[NSDictionary class]]) {
            self.pNum = [self objectOrNilForKey:kOneEntQNCmtPNum fromDictionary:dict];
            self.strCnt = [self objectOrNilForKey:kOneEntQNCmtStrCnt fromDictionary:dict];
            self.strId = [self objectOrNilForKey:kOneEntQNCmtStrId fromDictionary:dict];
            self.upFg = [self objectOrNilForKey:kOneEntQNCmtUpFg fromDictionary:dict];
            self.strD = [self objectOrNilForKey:kOneEntQNCmtStrD fromDictionary:dict];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation
{
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:self.pNum forKey:kOneEntQNCmtPNum];
    [mutableDict setValue:self.strCnt forKey:kOneEntQNCmtStrCnt];
    [mutableDict setValue:self.strId forKey:kOneEntQNCmtStrId];
    [mutableDict setValue:self.upFg forKey:kOneEntQNCmtUpFg];
    [mutableDict setValue:self.strD forKey:kOneEntQNCmtStrD];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description 
{
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict
{
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];

    self.pNum = [aDecoder decodeObjectForKey:kOneEntQNCmtPNum];
    self.strCnt = [aDecoder decodeObjectForKey:kOneEntQNCmtStrCnt];
    self.strId = [aDecoder decodeObjectForKey:kOneEntQNCmtStrId];
    self.upFg = [aDecoder decodeObjectForKey:kOneEntQNCmtUpFg];
    self.strD = [aDecoder decodeObjectForKey:kOneEntQNCmtStrD];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeObject:_pNum forKey:kOneEntQNCmtPNum];
    [aCoder encodeObject:_strCnt forKey:kOneEntQNCmtStrCnt];
    [aCoder encodeObject:_strId forKey:kOneEntQNCmtStrId];
    [aCoder encodeObject:_upFg forKey:kOneEntQNCmtUpFg];
    [aCoder encodeObject:_strD forKey:kOneEntQNCmtStrD];
}

- (id)copyWithZone:(NSZone *)zone
{
    OneEntQNCmt *copy = [[OneEntQNCmt alloc] init];
    
    if (copy) {

        copy.pNum = [self.pNum copyWithZone:zone];
        copy.strCnt = [self.strCnt copyWithZone:zone];
        copy.strId = [self.strId copyWithZone:zone];
        copy.upFg = [self.upFg copyWithZone:zone];
        copy.strD = [self.strD copyWithZone:zone];
    }
    
    return copy;
}


@end
