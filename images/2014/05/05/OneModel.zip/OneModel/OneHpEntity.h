//
//  OneHpEntity.h
//
//  Created by 新强 朱 on 14/11/29
//  Copyright (c) 2014 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface OneHpEntity : NSObject <NSCoding, NSCopying>

@property (nonatomic, strong) NSString *strContent;
@property (nonatomic, strong) NSString *strThumbnailUrl;
@property (nonatomic, strong) NSString *strLastUpdateDate;
@property (nonatomic, strong) NSString *strOriginalImgUrl;
@property (nonatomic, strong) NSString *strHpId;
@property (nonatomic, strong) NSString *sWebLk;
@property (nonatomic, strong) NSString *wImgUrl;
@property (nonatomic, strong) NSString *strPn;
@property (nonatomic, strong) NSString *strDayDiffer;
@property (nonatomic, strong) NSString *strAuthor;
@property (nonatomic, strong) NSString *strHpTitle;
@property (nonatomic, strong) NSString *strMarketTime;

+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict;
- (instancetype)initWithDictionary:(NSDictionary *)dict;
- (NSDictionary *)dictionaryRepresentation;

@end
