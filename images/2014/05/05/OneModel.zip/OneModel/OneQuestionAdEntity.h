//
//  OneQuestionAdEntity.h
//
//  Created by 新强 朱 on 14/11/29
//  Copyright (c) 2014 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class OneEntQNCmt;

@interface OneQuestionAdEntity : NSObject <NSCoding, NSCopying>

@property (nonatomic, strong) NSString *sWebLk;
@property (nonatomic, strong) NSString *strQuestionId;
@property (nonatomic, strong) NSString *strAnswerTitle;
@property (nonatomic, strong) NSString *strQuestionContent;
@property (nonatomic, strong) NSString *strQuestionMarketTime;
@property (nonatomic, strong) NSString *strLastUpdateDate;
@property (nonatomic, strong) NSString *strPraiseNumber;
@property (nonatomic, strong) NSString *strDayDiffer;
@property (nonatomic, strong) NSString *strQuestionTitle;
@property (nonatomic, strong) NSString *strAnswerContent;
@property (nonatomic, strong) OneEntQNCmt *entQNCmt;

+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict;
- (instancetype)initWithDictionary:(NSDictionary *)dict;
- (NSDictionary *)dictionaryRepresentation;

@end
